    google.charts.load("current", {packages:['corechart']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
      var dia = document.getElementById('dia').value;
      if(dia == "Lunes"){
      var ludinero = JSON.parse(localStorage.getItem("totalsem"));
      }
      if(dia == "Martes"){
        var madinero = JSON.parse(localStorage.getItem("totalsem"));
        }
        if(dia == "Miercoles"){
          var midinero = JSON.parse(localStorage.getItem("totalsem"));
          }
          if(dia == "Jueves"){
            var judinero = JSON.parse(localStorage.getItem("totalsem"));
            }
            if(dia == "Viernes"){
              var vidinero = JSON.parse(localStorage.getItem("totalsem"));
              }
              if(dia == "Sabado"){
                var sadinero = JSON.parse(localStorage.getItem("totalsem"));
                }
                if(dia == "Domingo"){
                  var dodinero = JSON.parse(localStorage.getItem("totalsem"));
                  }
      var data = google.visualization.arrayToDataTable([
        
        ['Element', 'Dinero generado', { role: 'style' }],
        ['Lunes', ludinero, '#b87333'],        
        ['Martes', madinero, 'silver'],  
        ['Miercoles', midinero, 'gold'],
        ['Jueves', judinero, 'color: #e5e4e2' ],
        ['Viernes', vidinero, 'silver'],
        ['Sabado', sadinero, 'gold'],
        ['Domingo', dodinero, '#b87333'],
      ]);

      var view = new google.visualization.DataView(data);
      view.setColumns([0, 1,
                       { calc: "stringify",
                         sourceColumn: 1,
                         type: "string",
                         role: "annotation" },
                       2]);

      var options = {
        title: "Ventas",
        width: 400,
        height: 200,
        bar: {groupWidth: "95%"},
        legend: { position: "none" },
      };
      var chart = new google.visualization.ColumnChart(document.getElementById("columnchart_values"));
      chart.draw(view, options);
  }    