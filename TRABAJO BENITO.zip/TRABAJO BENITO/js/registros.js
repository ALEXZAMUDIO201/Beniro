var guarnombre,guaremail,guarcontraseña;

function obtenerdatos(){
    guarnombre = document.getElementById("nombre").value;
    guaremail = document.getElementById("email").value;
    guarcontraseña = document.getElementById("contraseña").value;
    var r = [guarnombre,guaremail,guarcontraseña];
    return r;
}
var input = document.getElementsByTagName("INPUT");
    for (i=0; i<input.length; i++) {
    input[i].addEventListener("change",  function(){
     resultados = obtenerdatos();
     console.log(resultados);
     localStorage.setItem("nombre", guarnombre);
     localStorage.setItem("email", guaremail);
     localStorage.setItem("contraseña", guarcontraseña);
    });
   };
   