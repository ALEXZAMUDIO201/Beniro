
var guacorreo = localStorage.getItem('email');
var guacontraseña = localStorage.getItem('contraseña');
var entra = false;

var form = document.getElementById('formulario');
  form.addEventListener('submit', function(evt){
    var con = document.getElementById('contra').value;
    var cor = document.getElementById('correo').value;
    evt.preventDefault();
    form.reset();
    if (cor == guacorreo && con == guacontraseña) {
      var entra = true;
    } else {
      alert('El correo o la contraseña no son correctos');
    }

    if(entra == true){
      window.location.href = 'index.html';
      formulario.reset();
    }
  });